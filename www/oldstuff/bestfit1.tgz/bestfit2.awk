#best fit

NF==2 && isnum($1) && isnum($2) {
  n++
  x   =$1
  y[n]=$2

  #change the following lines to define the form of curve fit
  m=0
  f[n,++m]=1
  f[n,++m]=x
  f[n,++m]=x^2

}

#***********************************************************************
#test if a string contains a number

function isnum(x) {
  return x ~ /^[+-]?([0-9]+[.]?[0-9]*|[.][0-9]+)([eE][+-]?[0-9]+)?$/
}

#***********************************************************************
END {

  if (n==0) {
    print "no data found for best fit calculation"
    exit
  }

  #count number of function terms used
  m=0
  for (i in f) m++
  m=int(m/n+.5) # round to nearest integer

  if (m>n) {
    print "need at least",m,"data points for the specified form of fit"
    exit
  }

  #least square matrices
  for (i=1; i<=m; i++) {
    for (j=i; j<=m; j++) {
      sum=0
      for (k=1; k<=n; k++) sum=sum+f[k,i]*f[k,j]
      a[i,j]=a[j,i]=sum
    }
    sum=0
    for (k=1; k<=n; k++) sum=sum+f[k,i]*y[k]
    b[i]=sum
  }

  matsolve(a,b,coeff,m) # solve m x m matrix equations

  print "Best Fit using",m,"coefficients"
  print ""
  for (i=1; i<=m; i++) printf "%s%d%s%+.8g\n", "coeff[",i,"] = ",coeff[i]
  print ""

  #evaluate goodness of fit
  esqsum=emax=emin=0
  for (i=1; i<=n; i++) {
    yy=0
    for (j=1; j<=m; j++) yy+=coeff[j]*f[i,j]
    e=yy-y[i]
    esqsum+=e*e
    emin= (e<emin) ? e : emin
    emax= (e>emax) ? e : emax
  }
  print "errors: rms=",sqrt(esqsum/n),", min=",emin,", max=",emax

}

#***********************************************************************
function abs(x) {return x>=0 ? x : -x}

#***********************************************************************
# [a]*[x]=[b] , given a[1..n,1..n] and b[1..n] find x[1..n]
# leaving [a] and [b] unchanged
# global arrays used : lu_a[1..n,1..n], lu_indx[1..n] and lu_tmp[1..n]

function matsolve(a,b,x,n,  i,j,d) {
  for (i=1; i<=n; i++) {
    for (j=1; j<=n; j++) {
      lu_a[i,j]=a[i,j]
    }
    x[i]=b[i]
  }
  ludcmp(lu_a,n,d)
  lubksb(lu_a,n,x)
}

#***********************************************************************
# inspired by Numerical Recipes
function ludcmp(a,n,d,  tiny,i,j,k,aamax,sum,dum) {
  tiny=1.0e-20
  d=1
  for (i=1; i<=n; i++) {
    aamax=0
    for (j=1; j<=n; j++) {
      if (abs(a[i,j])>aamax) aamax=abs(a[i,j])
    }
    if (aamax==0) print "singular matrix"
    lu_tmp[i]=1/aamax
  }
  for (j=1; j<=n; j++) {
    if (j>1) {
      for (i=1; i<=(j-1); i++) {
        sum=a[i,j]
        if (i>1) {
          for (k=1; k<=(i-1); k++) sum-=a[i,k]*a[k,j]
          a[i,j]=sum
        }
      }
    }
    aamax=0
    for (i=j; i<=n; i++) {
      sum=a[i,j]
      if (j>1) {
        for (k=1; k<=(j-1); k++) sum-=a[i,k]*a[k,j]
        a[i,j]=sum
      }
      dum=lu_tmp[i]*abs(sum)
      if (dum>=aamax) {
        imax=i
        aamax=dum
      }
    }
    if (j!=imax) {
      for (k=1; k<=n; k++) {
        dum=a[imax,k]
        a[imax,k]=a[j,k]
        a[j,k]=dum
      }
      d=-d
      lu_tmp[imax]=lu_tmp[j]
    }
    lu_indx[j]=imax
    if (j!=n) {
      if (a[j,j]==0) a[j,j]=tiny
      dum=1/a[j,j]
      for (i=j+1; i<=n; i++) a[i,j]*=dum
    }
  }
  if (a[n,n]==0) a[n,n]=tiny
}

#***********************************************************************
# inspired by Numerical Recipes
function lubksb(a,n,b,  ii,ll,i,j,sum) {
  ii=0
  for (i=1; i<=n; i++) {
    ll=lu_indx[i]
    sum=b[ll]
    b[ll]=b[i]
    if (ii!=0) {
      for (j=ii; j<=(i-1); j++) sum=sum-a[i,j]*b[j]
    } else {
      if (sum!=0) ii=i
    }
    b[i]=sum
  }
  for (i=n; i>=1; i--) {
    sum=b[i]
    if (i<n) {
      for (j=i+1; j<=n; j++) sum=sum-a[i,j]*b[j]
    }
    b[i]=sum/a[i,i]
  }
}

#***********************************************************************
