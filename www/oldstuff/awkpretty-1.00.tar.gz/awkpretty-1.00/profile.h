#ifndef PROFILE_H__

#define PROFILE_H__ 1

#include "args.h"

#if defined(LINENO_T)
typedef LINENO_T lineno_t;
#else
typedef int lineno_t;
#endif

void	profile ARGS((void));
void	profile_begin_line ARGS((lineno_t lineno));
void	profile_end_line ARGS((lineno_t lineno));
void	profile_init ARGS((int argc, char **argv));
void	profile_term ARGS((void));

#endif /* PROFILE_H__ */
