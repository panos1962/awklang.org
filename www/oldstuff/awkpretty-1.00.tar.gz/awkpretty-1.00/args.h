#ifndef ARGS_H__

#define ARGS_H__	1

#if defined(__STDC__) || defined(__cplusplus)
#define STDC	1
#else
#define STDC	0
#endif

#if STDC
#define ARGS(parenthesized_list) parenthesized_list
#define VOID_ARG	void
#else
#define ARGS(parenthesized_list) ()
#define VOID_ARG
#define const
#endif

#endif /* ARGS_H__ */
