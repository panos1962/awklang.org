### ====================================================================
###  @Awk-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.00",
###     date            = "03 April 1999",
###     time            = "16:22:00 MST",
###     filename        = "awkpretty.awk",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "27196 535 1975 15572",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###	                   beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "awk, prettyprinter",
###     supported       = "yes",
###     docstring       = "This awk program implements the backend of
###                        awkpretty, a prettyprinter for awk programs.
###
###                        Usage:
###                            awklex -f program-file | \
###                                    awk -f awkpretty \
###                                            [ -v ACTIONCOLUMN=nnn ]
###                                            [ -v ACTIONSEPARATOR='...' ]
###                                            [ -v BLANKSONLY=nnn ]
###                                            [ -v COMMENTCOLUMN=nnn ]
###                                            [ -v FUNCTIONSEPARATOR='...' ]
###                                            [ -v INDENT=nnn ]
###                                            [ -v PURGESEMICOLONS=nnn ]
###                                            [ -v STANDARDCOMMENTS=nnn ]
###                                            [ -v WIDTH=nnn ]
###                                            >new-program-file
###
###                        or, more likely, using the shell script wrapper:
###
###                            awkpretty program-file >new-program-file
###
###	                   Complete documentation of awkpretty is provided
###	                   in the accompanying UNIX manual pages.
###
###                        The command-line options for this program are:
###
###                            ACTIONCOLUMN is the number of columns
###                            to indent the open brace of a
###
###                                pattern {action}
###
###                            code section (default: 16)
###
###                            ACTIONSEPARATOR, if nonempty, is a string
###                            containing whitespace, comments, and
###                            newlines, to be inserted between
###                            successive pattern/action pairs.  Leading
###                            and trailing newlines will be added if
###                            not already present.
###
###                            BLANKSONLY, if nonzero, forces
###                            indentation to use only blanks, instead
###                            of tabs and blanks (default: 0).
###
###                            COMMENTCOLUMN, if nonzero, causes
###                            inline comments to be indented to that
###                            column; otherwise, they are preceded by
###                            a single tab (default: 40).
###
###                            FUNCTIONSEPARATOR, if nonempty, is a
###                            string containing whitespace, comments,
###                            and newlines, to be inserted before
###                            function statements.  Leading and
###                            trailing newlines will be added if not
###                            already present.
###
###                            INDENT is the number of columns to
###                            indent for each syntactic level; values
###                            outside the range 0..8 are reset to the
###                            default (default: 4).
###
###                            PURGESEMICOLONS, if nonzero, causes
###                            unnecessary semicolons at end-of-line
###                            (except inside for(;;) loops) to be
###                            dropped (default: 0).
###
###                            STANDARDCOMMENTS, if nonzero, causes
###                            Lisp-style comment indentation:
###                            ``###COMMENT'' starts at beginning of
###                            line, ``##COMMENT'' starts at current
###                            indentation level, and ``#COMMENT'
###                            starts at current comment column (see
###                            COMMENTCOLUMN above).
###
###                            WIDTH, if nonzero and positive, causes
###                            line breaks to be inserted so as to
###                            prevent lines from exceeding that width
###                            (unless the token is too long, and
###                            cannot be profitably moved to a
###                            newline, in which case, it may extend
###                            beyond the specified line width).  A
###                            negative or zero value prevents
###                            statements from being broken across
###                            lines (default: 80).
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

### Implementation note: With the sole exception of function value(),
### there are no references to field numbers $1, $2, $3, ... beyond the
### definition of the first function.
###
### Optimization note: While it would be a little faster to use the
### numeric token identified in $1 of each input record obtained from
### awklex, that would require changing the code in this program if awk
### (and thus, awklex) changes.  We therefore use the alphanumeric token
### identifier in $2 instead, but in initialize(), remap it to an integer.
###

BEGIN					{ initialize() }

/^# line /				{ line_number_directive($0); next }

### Ignore all other lexical analyzer comments
/^ *#/					{ next }

### Ignore empty lines; although awklex does not produce any, other
### filters might.
/^[ \t]*$/				{ next }

### Skip token from apparent bug in lexical analyzer output
($3 == "}") && ($2 == "token 59")	{ next }

### Strictly, we should pass value() to process() as a second argument,
### but about half the time (e.g., whitespace and newlines), we don't
### need the value, so we optimize by delaying the call to value() until
### we really need it.
					{ process(typeof($2)) }

END					{ terminate() }

### ====================================================================

function classify(type, v)
{
    ## Classify the current token, and return its (possibly altered) value

    if (type == T_WHITESPACE)
	v = ""				# whitespace is common, easy, and standardized
    else if (type == T_NL)		# special case: newline token is empty in input stream
	v = "\n"
    else if (type == T_EOF)
	v = ""
    else
    {
	v = value()
	if (type == T_COMMENT)
	{
	    # If this appears to be an indentable comment, rather than
	    # a beginning-of-line comment, untabify it in order to get
	    # consistent comment appearance.
	    if (!(Pending_Newline || \
		  (STANDARDCOMMENTS && (substr(v,1,3) == "###"))))
		v = untabify(v)
	}
	else if (type == T_DO)
	{
	    Pending_Extra_Indent = 1
	    Do_Level++		# TO-DO: WRONG...need to have a stack of these values
	}
	else if (type == T_ELSE)
	    Pending_Extra_Indent = 1
	else if (type == T_FOR)
	    Pending_Extra_Indent = 1
	else if (type == T_IF)
	    Pending_Extra_Indent = 1
	else if (type == T_WHILE)
	{
	    if (Do_Level > 0)	# then inside ``do BODY while (CONDITION)''
		Do_Level--	# TO-DO: WRONG...need to have a stack of these values
	    else
		Pending_Extra_Indent = 1
	}
	else if (type == T_POWER) # convert old Fortran-style "**" to awk standard "^"
	    v = "^"
	else if ((type == T_ASGNOP) && (v == "**=")) # ditto for power-assignment operator
	    v = "^="
    }
    return (v)
}


function current_indentation()
{
    return (min(((Action_Level > 0) ? ACTIONCOLUMN : 0) + \
		INDENT * (Brace_Level + (Continued_Statement ? 1 : 0)), Max_Indent))
}


function fatal(message)
{
    warning("FATAL ERROR: " message)
    exit(1)
}


function force_into_range(v,min,max,default)
{
    ## If v is not set, return default.  Otherwise, in v is in min
    ## .. max, return v.  Otherwise, return the nearest of min and
    ## max.
    if (v == "")
	v = default
    else
    {
	v += 0				# coerce to integer
	if (v < min)
	    v = min
	else if (max < v)
	    v = max
    }
    return (v)
}


function initialize( maxint,n)
{
    FS = "\t"		# tabs separate input: NUMBER<TAB>TYPE<TAB>VALUE
			# but VALUE itself may contain further tabs, so
			# function value() handles that detail when necessary

    maxint = 2147483647			# 2147483647 == 2^31 - 1

    ## Initialize user command-line options

    ACTIONCOLUMN = (ACTIONCOLUMN == "") ? 16 : (0 + ACTIONCOLUMN)

    ## The user can set ACTIONSEPARATOR to, e.g., "#======...", but we
    ## must modify that to ensure it begins and ends with a newline:
    ACTIONSEPARATOR = newlines_surround((ACTIONSEPARATOR == "") ? "\n\n\n" : \
					unescape_spaces("" ACTIONSEPARATOR))

    BLANKSONLY += 0
    COMMENTCOLUMN = (COMMENTCOLUMN == "") ? 40 : (0 + COMMENTCOLUMN)

    ## The user can set FUNCTIONSEPARATOR to, e.g., "#======...", but we
    ## must modify that to ensure it begins and ends with a newline:
    FUNCTIONSEPARATOR = newlines_surround((FUNCTIONSEPARATOR == "") ? "\n\n\n" : \
					  unescape_spaces("" FUNCTIONSEPARATOR))

    INDENT = force_into_range(INDENT,0,8,4)
    PURGESEMICOLONS += 0
    STANDARDCOMMENTS += 0

    if (WIDTH == "0")			# special case: 0 means `infinity'
	WIDTH = maxint			# but unset ("") means default
    WIDTH = force_into_range(WIDTH,0,maxint,80)

    ## Initialize internal globals

    Action_Level = 0
    Brace_Level = 0
    Continued_Statement = 0
    Discardable_Newline = 0
    In_Function = 0
    Last_Type = -2
    Min_Text_Width = 24	# minimum available width for non-space tokens on a line
    Output_Column = 0
    Output_Line_Number = 1
    Pending_Extra_Indent = 0
    Pending_Newline = 0
    Pending_Whitespace = 0

    Max_Indent = WIDTH - Min_Text_Width

    ## Important optimization: To avoid relying on the possibly-changing
    ## token numbers from awklex, we instead remap token names to small
    ## integers which can be compared more quickly than strings.  For
    ## prettyprinting purposes, we only need to recognize a few of the
    ## 94 extended token types; the rest are classified as T_OTHER.

    T_OTHER			= -1

    ## hard-coded ASCII values (awk lacks a convenient char-to-int function)
    T_CLOSE_BRACE		= 125
    T_CLOSE_BRACKET		= 93
    T_CLOSE_PAREN		= 41
    T_COLON			= 58
    T_COMMA			= 44
    T_MINUS			= 45
    T_OPEN_BRACE		= 123
    T_OPEN_BRACKET		= 91
    T_OPEN_PAREN		= 40
    T_PERCENT			= 37
    T_PLUS			= 43
    T_QUERY			= 63
    T_SEMICOLON			= 59
    T_SLASH			= 47
    T_STAR			= 42
    

    for (n = 0; n < 256; ++n)
	Token_Map[sprintf("token %d",n)] = n

    Token_Map["AND"]		= T_AND		= n++
    Token_Map["ASGNOP"]		= T_ASGNOP	= n++
    Token_Map["BOR"]		= T_BOR		= n++
    Token_Map["COMMENT"]	= T_COMMENT	= n++
    Token_Map["DO"]		= T_DO		= n++
    Token_Map["ELSE"]		= T_ELSE	= n++
    Token_Map["EQ"]		= T_EQ		= n++
    Token_Map["FOR"]		= T_FOR		= n++
    Token_Map["FUNC"]		= T_FUNC	= n++
    Token_Map["GE"]		= T_GE		= n++
    Token_Map["GT"]		= T_GT		= n++
    Token_Map["IF"]		= T_IF		= n++
    Token_Map["LE"]		= T_LE		= n++
    Token_Map["MATCHOP"]	= T_MATCHOP	= n++
    Token_Map["NE"]		= T_NE		= n++
    Token_Map["NL"]		= T_NL		= n++
    Token_Map["NUMBER"]		= T_NUMBER	= n++
    Token_Map["POWER"]		= T_POWER	= n++
    Token_Map["REGEXPR"]	= T_REGEXPR	= n++
    Token_Map["VAR"]		= T_VAR		= n++
    Token_Map["WHILE"]		= T_WHILE	= n++
    Token_Map["WHITESPACE"]	= T_WHITESPACE	= n++
    Token_Map["XBEGIN"]		= T_XBEGIN	= n++
    Token_Map["XEND"]		= T_XEND	= n++
    Token_Map["token 0"]	= T_EOF		= n++

    ## Newline rules

    Newline_After[T_CLOSE_BRACE]	= 1
    Newline_After[T_OPEN_BRACE]		= 1

    Newline_Before[T_CLOSE_BRACE]	= 1
    Newline_Before[T_FUNC]		= 1
    Newline_Before[T_ELSE]		= 1
    Newline_Before[T_OPEN_BRACE]	= 1

    ## Line breaking rules: places where breaks are forbidden by the
    ## awk language, or are otherwise undesirable
    Nobreak_Before[T_CLOSE_BRACKET]	= 1
    Nobreak_Before[T_CLOSE_PAREN]	= 1
    Nobreak_Before[T_COMMA]		= 1
    Nobreak_Before[T_OPEN_BRACKET]	= 1
    Nobreak_Before[T_OPEN_PAREN]	= 1 # no space or break in "funct(args)"
    Nobreak_Before[T_SEMICOLON]		= 1

    ## Spacing rules for keywords

    Space_Before[T_DO]		= 1
    Space_Before[T_ELSE]	= 1
    Space_Before[T_FOR]		= 1
    Space_Before[T_IF]		= 1
    Space_Before[T_WHILE]	= 1

    Space_After[T_DO]		= 1
    Space_After[T_ELSE]		= 1
    Space_After[T_FOR]		= 1
    Space_After[T_FUNC]		= 1
    Space_After[T_IF]		= 1
    Space_After[T_WHILE]	= 1
    Space_After[T_XBEGIN]	= 1
    Space_After[T_XEND]		= 1

    ## Spacing rules for operators

    Space_After[T_AND]		= 1
    Space_After[T_ASGNOP]	= 1
    Space_After[T_BOR]		= 1
    Space_After[T_COLON]	= 1
    Space_After[T_EQ]		= 1
    Space_After[T_GE]		= 1
    Space_After[T_GT]		= 1
    Space_After[T_LE]		= 1
    Space_After[T_MATCHOP]	= 1
    Space_After[T_NE]		= 1
    Space_After[T_PERCENT]	= 1
    Space_After[T_POWER]	= 1
    Space_After[T_QUERY]	= 1
    Space_After[T_STAR]		= 1

    ## These operators should be followed by space only if they are
    ## binary, rather than unary, operators.  The function
    ## is_binary_add_op() distinguishes between unary and binary
    ## operators from a global history of preceding context.  Awk, gawk,
    ## and mawk all accept a space after a unary operator, but it isn't
    ## pretty to have one there.
    Space_After_Binary[T_MINUS]	= 1
    Space_After_Binary[T_PLUS]	= 1

    Binary_Add_Operator_Follows[T_VAR]		= 1
    Binary_Add_Operator_Follows[T_CLOSE_PAREN]	= 1
    Binary_Add_Operator_Follows[T_NUMBER]	= 1

    Space_Before[T_AND]		= 1
    Space_Before[T_ASGNOP]	= 1
    Space_Before[T_BOR]		= 1
    Space_Before[T_COLON]	= 1
    Space_Before[T_EQ]		= 1
    Space_Before[T_GE]		= 1
    Space_Before[T_GT]		= 1
    Space_Before[T_LE]		= 1
    Space_Before[T_MATCHOP]	= 1
    Space_Before[T_MINUS]	= 1
    Space_Before[T_NE]		= 1
    Space_Before[T_PERCENT]	= 1
    Space_Before[T_PLUS]	= 1
    Space_Before[T_POWER]	= 1
    Space_Before[T_QUERY]	= 1
    Space_Before[T_STAR]	= 1

    ## These interfere with prettyprinting of regular expressions;
    ## PROBLEM: regexps are returned as three tokens: slash REGEXPR
    ## slash, and so must be recognized specially here.  Maybe
    ## BEGIN_REGEXP and END_REGEXP should be emitted by awklex??
    ## TO-DO: figure out a workaround.
    ## For now, we recognize T_SLASH and T_REGEXPR specially in
    ## output_significant_token() and suppress spacing around T_SLASH:
    ## Space_After[T_SLASH]	= 1
    ## Space_Before[T_SLASH]	= 1
}


function is_binary_add_op(type)
{
    if ((type == T_PLUS) || (type == T_MINUS))
	return (Last_Type in Binary_Add_Operator_Follows)
    else
	return (0)
}


function line_number_directive(s, k,n,parts)
{
    ## Typical argument:
    ## # line 272 "/u/sy/beebe/tex/bib/bibtex-to-html.awk"
    n = split(s,parts,"[ ]")
    Input_Line_Number = parts[3]
    Input_Filename = parts[4]
    for (k = 5; k <= n; ++k)
	Input_Filename = Input_Filename " " parts[k]
    sub("^\"","",Input_Filename)
    sub("\"$","",Input_Filename)
}


function maybe_discardable_newline(type)
{
    if ((type == T_OPEN_BRACE) || (type == T_CLOSE_BRACE))
    {
	## In the "pattern { action }" section, level-0 braces CANNOT
	## be moved to new lines!
	if (In_Function || ((!In_Function) && (Brace_Level > 0)))
	    Discardable_Newline++
    }
    else
	Discardable_Newline++
}


function maybe_pending_newline(type)
{
    if ((type == T_OPEN_BRACE) || (type == T_CLOSE_BRACE))
    {
	## In the "pattern { action }" section, level-0 braces CANNOT
	## be moved to new lines!
	if (In_Function || ((!In_Function) && (Brace_Level > 0)))
	    Pending_Newline = 1
    }
    else
	Pending_Newline = 1
}


function min(a,b)
{
    return ((a < b) ? a : b)
}


function newlines_surround(s)
{
    if (s !~ "^\n")
	s = "\n" s
    if (s !~ "\n$")
	s = s "\n"
    return (s)
}


function output(type,v)
{
    if (type == T_WHITESPACE)
	Pending_Whitespace++		# whitespace only produces a side effect
    else if (type == T_COMMENT)
	output_comment(v)
    else if (type == T_NL)
    {
	Discardable_Newline = 0		# real newlines cancel discardable ones
	Pending_Newline++
    }
    else if (type == T_FUNC)
    {
	if ((Output_Line_Number > 1) || (Significant_Token_Count > 0))
	    output_verbatim(FUNCTIONSEPARATOR)
	Add_Level_After_Line_Number = 0
	Pending_Newline = 0
	Pending_Whitespace = 0
	output_significant_token(type,v)
	In_Function = 1
    }
    else if (type == T_EOF)
	;				# ignore EOF tokens
    else if ((Action_Level == 0) && !In_Function && Pending_Newline)
    {
	if ((Output_Line_Number > 1) || (Significant_Token_Count > 0))
	    output_verbatim(ACTIONSEPARATOR)
	Pending_Newline = 0
	output_significant_token(type,v)
    }
    else
	output_significant_token(type,v)
    Last_Type = type
}


function output_comment(v)
{
    ## print "DEBUG: COMMENTCOLUMN=" COMMENTCOLUMN ", Output_Column=" Output_Column >"/dev/stderr"
    if (Pending_Newline)
    {
	output_newline()
	if (Pending_Newline > 1)	# reduce multiple newlines to just a pair
	    output_newline()
	Pending_Newline = 0
    }
    if (STANDARDCOMMENTS)
    {
	if (v ~ /^###/)			# flush-left comment
	{
	    if (Output_Column > 0)
		output_newline()
	}
	else if (v ~ /^##/)		# comment indented to current level
	{
	    if (Output_Column > current_indentation())
		output_newline()
	    output_leading_indentation()
	}
	else				# comment indented to comment column
	{
	    if (Output_Column == 0)
	    {
		if (Pending_Whitespace)	# then indent to current level
		{
		    v = "#" untabify(v)
		    output_leading_indentation()
		}
		else			# convert to flush-left comment
		    v = "##" untabify(v)
	    }
	    else if (COMMENTCOLUMN > 0)	# then have unique comment column
	    {
		if (Output_Column < COMMENTCOLUMN)
		    output_spacing(COMMENTCOLUMN - Output_Column)
		else
		{
		    output_newline()
		    output_spacing(COMMENTCOLUMN)
		}
	    }
	    else
	    {
		## The updated Output_Column will be wrong here if we
		## use a tab, but that doesn't matter, since the next
		## token is always a newline anyway.
		output_string(BLANKSONLY ? " " : "\t")
	    }
	}
    }
    else				# output comments unmodified
    {
	## The updated Output_Column will be wrong here if we use a tab,
	## but that doesn't matter, since the next token is always a
	## newline anyway, and we won't need to refer to Output_Column
	## until at least the next line.
	if (Output_Column == 0)
	    output_leading_indentation()
	else if (Output_Column < COMMENTCOLUMN)
	    output_spacing(COMMENTCOLUMN - Output_Column)
	else
	{
	    output_newline()
	    output_spacing(COMMENTCOLUMN)
	}
    }
    output_string(v)
}


function output_leading_indentation()
{
    output_spacing(current_indentation())
}


function output_newline()
{
    print ""
    Continued_Statement = 0
    Output_Column = 0
    Output_Line_Number++
    Significant_Token_Count = 0
}


function output_significant_token(type,v, lenv,new_line_length,single_statement_indent)
{
    if (v == "")
	fatal("INTERNAL CONFUSION: empty value passed to output_significant_token()")

    if ((type in Newline_Before) && (Output_Column > 0))
	maybe_pending_newline(type)
    else if (type in Space_Before)
	Pending_Whitespace = 1

    if (type == T_CLOSE_BRACE)
	Brace_Level--
    else if (type == T_OPEN_BRACE)
    {
	if ((Brace_Level == 0) && !In_Function)
	{
	    Action_Level = 1
	    if (Pending_Newline || Discardable_Newline)
	    {				# have LONG-PATTERN { ACTION }
		output_pending_newline()
		output_leading_indentation()
	    }
	    else if (Output_Column > current_indentation())
	    {				# have LONG-PATTERN { ACTION }
		output_string(" \\")
		output_newline()
		output_leading_indentation()
	    }
	    else			# have SHORT-PATTERN { ACTION }
		output_spacing(current_indentation() - Output_Column)
	    Pending_Whitespace = 0
	}
    }
    output_pending_newline()

    if (Pending_Extra_Indent)
    {
	Add_Level_After_Line_Number = Output_Line_Number
	Pending_Extra_Indent = 0
    }

    if (Output_Column == 0)		# then supply current line indentation
    {
	if ((Add_Level_After_Line_Number > 0) && \
		 (Add_Level_After_Line_Number < Output_Line_Number))
	{			# then on first line after a line causing indentation increase
	    if (type != T_OPEN_BRACE)
	    {
		Brace_Level++
		single_statement_indent = 1
	    }
	    Add_Level_After_Line_Number = 0
	}
	output_leading_indentation()
	Pending_Whitespace = 0
    }
    else if (Pending_Whitespace)
    {
	output_string(" ")
	Pending_Whitespace = 0
    }

    ## Line wrapping may happen only after at least one visible token has
    ## been output, and then only if the pending token would make the
    ## current line too long, and yet could fit on the next line.
    ##
    ## Because regular expressions unfortunately appear as a three-token
    ## sequence, T_SLASH T_REGEXPR T_SLASH, we have to prevent wrapping
    ## between those tokens, and that effectively means that, without
    ## token lookahead, we cannot wrap after a slash, sigh...
    ##
    ## We also cannot wrap before an open parenthesis, because awk
    ## function calls do not permit space between the function name and
    ## the following open parenthesis.

    if ((type == T_SLASH) || (type == T_REGEXPR) || (type == T_OPEN_PAREN))
    {
	## We need to clear these flags to avoid input like "\n/^pattern"
	## being output as "/\n^pattern".
	Pending_Whitespace = 0
	Pending_Newline = 0
    }
    else if (Output_Column > 0)
    {					# check for need to wrap long line
	lenv = length(v)
	new_line_length = Output_Column + lenv
	if ((new_line_length > WIDTH) &&
	    ((current_indentation() + lenv) <= WIDTH) &&
	    !(type in Nobreak_Before))
	{				# then line wrapping is required
	    output_string(" \\")
	    output_newline()
	    Continued_Statement = 1
	    output_leading_indentation()
	}
    }

    output_string(v)

    if (single_statement_indent)
    {
	single_statement_indent = 0
	Brace_Level--
    }

    if (type == T_OPEN_BRACE)
	Brace_Level++
    else if (type == T_CLOSE_BRACE)
    {
	if ((Brace_Level == 0) && !In_Function)
	    Action_Level = 0
	if (Brace_Level <= 0)
	    In_Function = 0
    }

    if (type in Newline_After)
	maybe_discardable_newline(type)
    else if (type in Space_After)
	Pending_Whitespace = 1
    else if ((type in Space_After_Binary) && is_binary_add_op(type))
	Pending_Whitespace = 1

    Significant_Token_Count++
}


function output_pending_newline()
{
    ## Output pending newlines, unless we are already at beginning of line

    if (Discardable_Newline && (Pending_Newline <= 0))
    {
	Discardable_Newline = 0
	Pending_Newline = 1
    }

    if (Pending_Newline && (Output_Column > 0))
    {
	output_newline()
	if (Pending_Newline > 1)	# reduce multiple newlines to just a pair
	    output_newline()
	Pending_Newline = 0
	Pending_Whitespace = 0
    }
}


function output_spacing(columns, goal_column,ntabs)
{
    goal_column = Output_Column + columns
    ntabs = (BLANKSONLY ? 0 : (int(goal_column/8) - int(Output_Column/8)))

    Output_Column = 8*int((Output_Column + 8*ntabs)/8)

    while (ntabs-- > 0)
	printf("\t")

    while (Output_Column < goal_column)
    {
	printf(" ")
	Output_Column++
    }
}


function output_string(v)
{
    ## Output a string, assuming it contains neither tabs nor newlines, so that
    ## Output_Column can be easily updated.
    printf("%s",v)
    Output_Column += length(v)
}


function output_verbatim(s, k,n,parts)
{
    n = split(s,parts,"\n")
    for (k = 1; k <= n; ++k)
    {
	output_string(parts[k])
	if (k < n)			# NB: last part has no final newline
	    output_newline()
    }
}


function process(type)
{
    ## This is the complex version of process(), with logic to handle
    ## indentation of various statement types.  We split it into two
    ## functions to reduce complexity.
    output(type,classify(type))
}


function terminate()
{
    output_pending_newline()
    if (Output_Column > 0)
	output_newline()
}


function typeof(token_name)
{
    return ((token_name in Token_Map) ? Token_Map[token_name] : T_OTHER)
}


function unescape_spaces(s)
{
    gsub(/\\s/," ",s)
    return (s)
}


function untabify(s, chars,column,k,lens,n)
{
    if (index(s,"\t") > 0)	# economization: this operation is expensive
    {
	n = split(s,chars,"")	# NB: needs 2-May-1996 bwkawk extension (gawk and mawk are okay)
	lens = length(s)
	if (n != lens)		# then must have old awk, so unpack it
	{			# the slow way, sigh...
	    n = lens
	    for (k = 1; k <= n; ++k)
		chars[k] = substr(s,k,1)
	}
	s = ""
	column = 0
	for (k = 1; k <= n; ++k)
	{
	    if (chars[k] == "\t")
	    {
		do
		{
		    column++
		    s = s " "
		}
		while ((column % 8) != 0)
	    }
	    else
	    {
		column++
		s = s chars[k]
	    }
	}
    }
    return (s)
}


function value( k,v)
{
    if (NF == 3 )		# simple case: no tabs in token
	v = $3
    else			# complex case: reconstruct token from $3 TAB $4 TAB ... $NF
    {
	v = $3
	for (k = 4; k <= NF; ++k)
	    v = v "\t" $k
    }
    return (v)
}


function warning(message)
{
    print FILENAME ":" FNR ":%%" message >"/dev/stderr"
}
