/* /u/sy/beebe/bwkawk/cpuclock.c, Tue Nov 12 12:09:42 1996 */
/* Edit by Nelson H. F. Beebe <beebe@plot79.math.utah.edu> */

#include "config.h"

#include <math.h>			/* only for sin() function below */

#include <time.h>			/* for clock() and CLOCKS_PER_SEC */

#if defined(CLOCKS_PER_SEC)
#define CLOCK_TICKS() clock()
#else
/* This should not happen in the Standard C environment assumed by awk,
but if clock() and CLOCKS_PER_SEC are not available, fall back to
pre-Standard C UNIX times() */
#include <sys/types.h>			/* needed on some systems */
#include <sys/times.h>			/* for struct tms */
static struct tms times_buffer;
#define CLOCK_TICKS() (times(&times_buffer),times_buffer.tms_utime+times_buffer.tms_stime)
#include <limits.h>			/* for CLK_TCK on many systems */
#include <time.h>			/* for CLK_TCK on some systems */
#if defined(CLK_TCK)
#define CLOCKS_PER_SEC	CLK_TCK
#else
#include <sys/param.h>			/* for HZ or AHZ */
#if defined(HZ)
#define CLOCKS_PER_SEC	HZ
#else
#if defined(AHZ)
#define CLOCKS_PER_SEC	AHZ
#else
#define CLOCKS_PER_SEC	60		/* default to common value (but 50 and 100 are also used) */
#endif /* defined(AHZ) */
#endif /* defined(HZ) */
#endif /* defined(CLK_TCK) */
#endif /* defined(CLOCKS_PER_SEC) */

#include "cpuclock.h"

CPU_clock_t
CPU_clock(VOID_ARG)
{
#if defined(__GNUC__) && defined(__alpha__)
    static long	clock_offset = 0L;	/* preserved across calls */
    static long	t_last = 0L;		/* preserved across calls */
    long	t = 0L;			/* initializations suppress compiler warnings */
    long	u = 0L;			/* initializations suppress compiler warnings */

    /*******************************************************************
      The book ``Alpha Architecture Handbook'', Digital Equipment
      Corporation (1992), p. 104, discusses the Alpha RPCC (Read Process
      Cycle Counter) instruction, and gives a 4-instruction code
      sequence to compute a 32-bit cycle count:

	  rpcc	$0		# read the process cycle counter
	  sll	$0, 32, $1	# line up the offset and count fields
	  addq	$0, $1, $0	# do add
	  srl	$0, 32, $0	# zero extend the cycle count to 64 bits

      RPCC returns a 64-bit value: the upper 32 bits is an unsigned bias
      to be added to the unsigned lower 32 bits to get the cycle count
      for the current process.  Experiments on three different machines
      under differing load conditions indicate that (a) the upper 32
      bits changes each time RPCC is executed, and (b) the timer is not
      reset at the start of the process time slice.  The latter point
      means that the cycles counted reflect ALL processes in the system,
      not just the one being profiled.  Thus, profiling with this cycle
      counter will be unreliable unless the system is very lightly
      loaded; fortunately, in a workstation environment, this is often
      the case.

      At 100MHz (all DEC Alpha workstations are at least that fast), a
      32-bit signed integer counter will wrap every

      		(2^31 - 1)/100,000,000 = 21.47 sec.

      DEC Alpha processors with clock rates of 1000MHz are expected by
      the late 1990s, so the counter could wrap in as little as 2.15
      sec.  Thus, we have to check for the wrapping, and increment
      clock_offset to accumulate the count lost by the wrapping, and the
      user needs to call us at least every 2 sec to avoid loss of a
      clock_offset increment.  It is a mystery why the RPCC counter was
      not defined to be a 64-bit value in the first place!
    *******************************************************************/

    asm("rpcc %0; sll  %0, 32, %1; addq %0, %1, %0; srl  %0, 32, %0" \
	: "=r" (t) : "r" (u));
					  /* get the cycle count in t */
    if (t < t_last)			/* then 32-bit cycle timer wrapped */
	  clock_offset += 0x100000000L;

    t_last = t;				/* remember last cycle count */

    return (clock_offset + t);

#else  /* NOT (defined(__GNUC__) && defined(__alpha__)) */
#if defined(_IBMR2) && defined(HAVE_READ_REAL_TIME)
    timebasestruct_t s;

    read_real_time(&s, TIMEBASE_SZ);     
    time_base_to_time(&s, TIMEBASE_SZ);

    return ((CPU_clock_t)s.tb_high * 1000000000L + (CPU_clock_t)s.tb_low);

#else
  return ((CPU_clock_t)CLOCK_TICKS());	/* use the (expensive) kernel clock instead */
#endif
#endif
}

long
CPU_CLOCKS_PER_SEC(VOID_ARG)
{					/* return the processor MHz rating, which  */
					/* can be used to convert CPU_clock() */
					/* counts to time values */
    static long MHz = 0L;		/* preserved across calls */

    if (MHz == 0L)
    {					/* expensive: do only on the first call */
#if defined(__alpha__)
        /* The only portable way to relate clock time to cycle counts is
	   to perform a computation measuring deltas of both values,
	   then compute the ratio of the two deltas.  Experiments on
	   three DEC Alpha systems with clock rates of 100MHz, 125MHz,
	   and 250MHz led to the particular choice of iteration count
	   and loop body.  The expensive clock() call is done only
	   rarely, and we bail out of the loop after 2 sec of execution,
	   which is enough for about 1% accuracy with a 60Hz -- 100Hz
	   clock.  This code of course relies on the compiler not
	   optimizing away the loop body! */

	CPU_clock_t c_begin,c_end;
	clock_t t_begin,t_end;
	long k;

	t_begin = t_end = CLOCK_TICKS();
	c_begin = CPU_clock();

	for (k = 1; k <= 5000000L; ++k)	/* This loop runs about 2 sec. */
	{
	    (void)sin(3.12345);		/* Arbitrary function to burn some cycles. */
	    if ((k % 1000000L) == 0)	/* Sample expensive clock, but only rarely. */
	    {
		t_end = CLOCK_TICKS();
		if ((t_end - t_begin) > 2 * CLOCKS_PER_SEC) /* Bail out after 2 sec. */
		    break;
	    }
	}

	c_end = CPU_clock();

	if (t_end == t_begin)		/* Should never happen. */
	  t_end++;			/* Prevent zero divide below. */

	MHz = (long)(0.5 + ( (double)(c_end - c_begin)/
			    ((double)(t_end - t_begin)/(double)CLOCKS_PER_SEC)));
#else
#if defined(_IBMR2) && defined(HAVE_READ_REAL_TIME)
	MHz = 1000000000L;
#else
	MHz = (long)CLOCKS_PER_SEC;
#endif
#endif
	if (MHz == 0L)			/* Should never happen. */
	    MHz = 1L;			/* Prevent this loop being done again. */
    }

    return (MHz);
}
