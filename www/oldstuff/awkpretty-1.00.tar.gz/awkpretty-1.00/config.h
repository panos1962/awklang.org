/* config.h.  Generated automatically by configure.  */
/* config.hin.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the infinity function.  */
/* #undef HAVE_INFINITY */

/* Define if you have the read_real_time function.  */
/* #undef HAVE_READ_REAL_TIME */
