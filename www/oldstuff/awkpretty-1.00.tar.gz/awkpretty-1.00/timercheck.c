#include <stdio.h>

typedef long long LONG;

LONG foo(void)
{
  LONG v;

  v = 1000000L + sizeof(LONG);
  asm(	"loop:	mftbu	3\n"
	"	mftb	4\n"
	"	mftbu	5\n"
	"	cmpw	5,3\n"
	"	bne	loop");
  return;		/* NB: intentionally NO value provided */
			/* so as to preserve counter from mftb */
}

int main(void)
{
  LONG t;
  
  t = foo();
  
  printf("%lld\n", (long long)t);

  return (0);
}
