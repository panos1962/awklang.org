/* wwlex() is a wrapper for yylex(), outputting a token stream to
 * stdout, and then silently discarding COMMENT and WHITESPACE tokens
 * before returning any other token type to its called (in yyparse()).
 *
 * wwrun() is a dummy function that replaces the run() from run.c, so
 * that main.c needs no modifications at all.
 *
 * Compilation of main.c requires -Drun=wwrun and compilation of ytab.c
 * requires -Dyylex=wwlex to accomplish the invisible modifications of
 * those two files.
 */

#include <stdio.h>
#include <ctype.h>
#include "awk.h"
#include "ytab.h"


static void
wwlineno (int token_type)
{
    if (token_type != 0)	/* token_type == 0 means EOF, and thus, no line number */
    {
	int file_lineno;
	extern char *pfile[];
	extern int curpfile;

	file_lineno = ((token_type == NL) ? (lineno - 1) : lineno);
	(void) printf ("# line %d \"%s\"\n",
		       file_lineno,
		       ((pfile[curpfile] == (char *) NULL) ?
			"/dev/stdin" : pfile[curpfile]));
    }
}


int
wwlex (void)
{
    int token_type;
    char *s;
    static int last_error_lineno = 0;
    static int nt = 0;		/* token number on current line */
    extern char *yytext;	/* this type would change if flex were used */

    do
    {
	token_type = yylex ();

	if (nt == 0)
	    wwlineno (token_type);

	if (errorflag && (lineno != last_error_lineno))
	{
	    (void) printf ("# ERROR\n");
	    last_error_lineno = lineno;
	}

	nt++;

	switch (token_type)
	{
	case 0:
	case NL:
	    s = "";
	    break;
	case REGEXPR:
	    s = yytext;
	    break;
	case STRING:
	    s = yytext;
	    break;
	default:
	    s = yytext;
	    break;
	}
	if (token_type == STRING)
	{	/* must reencode the string with Standard C escape characters */
	    (void) printf ("%3d\t%s\t\"", token_type, tokname (token_type));
	    for (; *s; ++s)
	    {
		unsigned int u;

		u = 0xff & (unsigned int) (*s);
		switch (u)
		{
		case '\007':	/* pre-Standard-C compilers lack \a (alarm bell) */
		    (void) fputs ("\\a", stdout);
		    break;
		case '\b':
		    (void) fputs ("\\b", stdout);
		    break;
		case '\f':
		    (void) fputs ("\\f", stdout);
		    break;
		case '\n':
		    (void) fputs ("\\n", stdout);
		    break;
		case '\r':
		    (void) fputs ("\\r", stdout);
		    break;
		case '\t':
		    (void) fputs ("\\t", stdout);
		    break;
		case '\v':
		    (void) fputs ("\\v", stdout);
		    break;
		case '\"':
		    (void) fputs ("\\\"", stdout);
		    break;
		case '\\':
		    (void) fputs ("\\\\", stdout);
		    break;
		default:
		    if (isprint (u))
			(void) putchar ((int) u);
		    else
			(void) printf ("\\%03o", (u & 0xff));
		}
	    }
	    (void) fputs ("\"\n", stdout);
	}
	else
	    (void) printf ("%3d\t%s\t%s\n",
			   token_type, tokname (token_type), s);
	if (token_type == NL)
	    nt = 0;
    }
    while ((token_type == COMMENT) || (token_type == WHITESPACE));

    return (token_type);
}


void
wwrun (Node * a)		/* execution of parse tree starts here */
{
    a = a;			/* suppress unused-argument compiler warnings */
}


#if defined(__LCC__) && !defined(HAVE_INFINITY)
/* replacement for missing function with lcc 4.0 on Sun Solaris 2.5 */
double
infinity (void)
{
    double x;
    x = 0.0;
    return (1.0 / x);
}
#endif
