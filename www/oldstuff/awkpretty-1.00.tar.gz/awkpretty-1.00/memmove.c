#include <stdio.h>
#include <stdlib.h>

void*
memmove (void* target, const void* source, size_t n)
{
    if ((target != (void*) NULL) && (source != (const void*) NULL) && (n > 0))
    {
	register const char *s;
	register char *t;

	s = (const char *) source;
	t = (char *) target;

	if ((t > s) && (t < (s + n)))	/* overlap: destructive copy if forward */
	{				/* so copy backward */
	    for (--n; n > 0; --n)
		t[n] = s[n];
	    t[0] = s[0];
	}
	else
	{				/* forward copy ok */

	    for (; n > 0; --n)
		*t++ = *s++;
	}
    }
    return (target);
}
