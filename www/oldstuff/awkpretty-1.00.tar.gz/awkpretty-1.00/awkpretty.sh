#! /bin/sh
### ====================================================================
###  @UNIX-shell-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.01",
###     date            = "14 October 1999",
###     time            = "14:44:39 MDT",
###     filename        = "awkpretty.sin",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "18557 232 701 7450",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "awk, prettyprinter",
###     supported       = "yes",
###     docstring       = "This Bourne-shell-compatible script directs
###                        the lexical analysis and prettyprinting of
###                        awk programs.
###
###                        See the accompanying UNIX manual pages for
###                        complete documentation of all of the
###                        command-line options.
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

### This value is set at configure time in the output awkpretty.sh file:
AWK=/usr/local/bin/gawk

### Special check for developer: files in local directory

if test -f awkpretty.awk
then
	LIBDIR=.
else
	LIBDIR=/usr/local/share/awkpretty/awkpretty-@VERSION@
fi

if test -f awklex
then
	BINDIR=.
else
	BINDIR=@BINDIR@
fi

### Set defaults; these must match those set in awkpretty.awk, and
### documented in awkpretty.man.
AWKLEX="$BINDIR/awklex -f"
AWKPRETTY="`basename $0`"
actioncolumn=16
actionseparator=
blanksonly=0
commentcolumn=40
files=""
functionseparator=
reorderfunctions=0
indent=4
initfile=$HOME/.awkprettyrc
purgesemicolons=0
standardcomments=0
width=80

### These filters may be inserted between awklex and awkpretty.awk to
### implement certain command-line options:
FILTERS=
FILTERGLOBALS="$AWK -f $LIBDIR/globals.awk"
FILTERSORTFCN="$AWK -f $LIBDIR/sortfcn.awk"

processcommandline()
{
	while test $# -gt 0
	do
		case $1 in
		-x|--action-column|--action-colum|--action-colu|--action-col|--action-co|--action-c)
			actioncolumn=$2
			shift
			;;
		-y|--action-separator|--action-separato|--action-separat|--action-separa|--action-separ|--action-sepa|--action-sep|--action-se|--action-s)
			actionseparator="$2"
			shift
			;;
		-a|--awklex-input|--awklex-inpu|--awklex-inp|--awklex-in|--awklex-i|--awklex-|--awklex|--awkle|--awkl|--awk|--aw|--a)
			AWKLEX=cat
			;;
		-b|--blanks-only|--blanks-onl|--blanks-on|--blanks-o|--blanks-|--blanks|--blank|--blan|--bla|--bl|--b)
			blanksonly=1
			;;
		-c|--comment-column|--comment-colum|--comment-colu|--comment-col|--comment-co|--comment-c|--comment-|--comment|--commen|--comme|--comm|--com|--co|--c)
			commentcolumn=$2
			shift
			;;
		-f|--file|--fil|--fi|--f)
			files="$files $2"
			shift
			;;
		-z|--function-separator|--function-separato|--function-separat|--function-separa|--function-separ|--function-sepa|--function-sep|--function-se|--function-s|--function-|--function|--functio|--functi|--funct|--func|--fun|--fu)
			functionseparator="$2"
			shift
			;;
		-g|--globals|--global|--globa|--glob|--glo|--gl|--g)
			FILTERS="$FILTERS $FILTERGLOBALS |"
			;;
		-h|-[?]|--[?]|--help|--hel|--he|--h)
			usage
			exit 0
			;;
		-i|--indent|--inden|--inde|--ind|--in|--i)
			indent=$2
			shift
			;;
#		-p|--purge-semicolons|--purge-semicolon|--purge-semicolo|--purge-semicol|--purge-semico|--purge-semic|--purge-semi|--purge-sem|--purge-se|--purge-s|--purge-|--purge|--purg|--pur|--pu|--p)
#			purgesemicolons=1
#			;;
		-q|--quick|--quic|--qui|--qu|--q)
			initfile=
			;;
		-r|--reorder-functions|--reorder-function|--reorder-functio|--reorder-functi|--reorder-funct|--reorder-func|--reorder-fun|--reorder-fu|--reorder-f|--reorder-|--reorder|--reorder|--reorde|--reord|--reor|--reo|--re|--r)
			reorderfunctions=1
			FILTERS="$FILTERS $FILTERSORTFCN |"
			;;
		-s|--standard-comments|--standard-comment|--standard-commen|--standard-comme|--standard-comm|--standard-com|--standard-co|--standard-c|--standard-|--standard|--standar|--standa|--stand|--stan|--sta|--st|--s)
			standardcomments=1
			;;
		-v|--version|--versio|--versi|--vers|--ver|--ve|--v)
			echo "$AWKPRETTY Version @VERSION@ @DATE@"
			exit 0
			;;
		-w|--width|--widt|--wid|--wi|--w)
			width=$2
			shift
			;;
		-*)
			for f in 1
			do
				echo "Unrecognized option $1"
				usage
			done 1>&2
			exit 1
			;;
		*)
			files="$files $1"
			;;
		esac
		shift
	done
}

usage()
{
	echo "Usage:"
	echo "    awkpretty [-?] [-a] [-b] [-c nnn] [-f file] [-g] [-h] [-i nnn] [-p] [-q] \\"
	echo "              [-r] [-s] [-v] [-w nnn] [-x nnn ] [-y str] [-z str] [file(s)]"
	echo ""
	echo "or"
	echo ""
	echo "    awkpretty [--?] [--action-column nnn] [--action-separator str] \\"
	echo "              [--awklex-input] [--blanks-only] [--comment-column nnn] \\"
	echo "              [--file file] [--globals] [--help] [--indent nnn] \\"
#	echo "              [--purge-semicolons] [--quick] [--reorder-functions] \\"
#	echo "              [--standard-comments] [--version] [--width nnn] [file(s)]"
	echo "              [--quick] [--reorder-functions] [--standard-comments] \\"
	echo "              [--version] [--width nnn] [file(s)]"
}

### Prescan the command line to see if we have a --quick option to
### suppress loading of user option file.

for f in "$@"
do
	case $f in
	-q|--quick|--quic|--qui|--qu|--q)
		initfile=
		;;
	*)
		;;
	esac
done

### If a user option file was not suppressed, and it exists, and is
### readable, process it for any command-line options, so the latter can
### override option file settings.  We strip comment lines beginning with
### option whitespace followed by a sharp (#).

if test -n "$initfile" -a -r "$initfile"
then
	processcommandline `cat $initfile | egrep -v '^[ 	]*#.*$' `
fi

processcommandline "$@"

### If there are no command-line files, set files to the magic hyphen.

if test -z "$files"
then
	files=-
fi

### Loop over the files, lexically analyzing and prettyprinting one at
### a time.  We need to use eval here, because FILTERS may contain
### pipe operators which would be interpreted as ordinary characters
### without eval.
for f in $files
do
	eval " \
	$AWKLEX $f | \
		$FILTERS \
		$AWK	-f $LIBDIR/awkpretty.awk \
			-v ACTIONCOLUMN=$actioncolumn \
			-v ACTIONSEPARATOR="$actionseparator" \
			-v BLANKSONLY=$blanksonly \
			-v COMMENTCOLUMN=$commentcolumn \
			-v FUNCTIONSEPARATOR="$functionseparator" \
			-v INDENT=$indent \
			-v PURGESEMICOLONS=$purgesemicolons \
			-v STANDARDCOMMENTS=$standardcomments \
			-v WIDTH=$width \
	"
done
