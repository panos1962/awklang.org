BEGIN   { initialize() }
        { print FNR ":" $0 }
END     { terminate() }

function initialize()
{
    print "Hello, world"  
}

function terminate()
{
    print "Goodbye, world"  
}
