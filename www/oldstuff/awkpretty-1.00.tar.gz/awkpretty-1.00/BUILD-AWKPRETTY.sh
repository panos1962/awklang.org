#! /bin/sh
# This script configures and builds an optimized version of awkpretty on
# all local systems at the University of Utah Mathematics and Physics
# Departments.
#
# Usage:
#	./BUILD-AWKPRETTY.sh
#
# [21-Apr-1999]

# Default C compiler
CC=c89
YACC=yacc
YFLAGS=-d

# Adjustments for particular systems

case "`uname -s`" in
	AIX)
		CC=c89
		CFLAGS='-O3 -qarch=ppc'
		# Don't use -qarch=ppc: AIX doesn't emulate those extra instructions
		# on older models that lack them, sigh... Sun does a much better job
		CFLAGS='-O3'
		;;
	HP-UX)
		CC=c89
		# Don't use +O4: the resulting executable does not run properly
		CFLAGS='+O3'
		;;
	IRIX)
		CC='cc -cckr'
		CFLAGS='-O2'
		# IRIX 5.3 yacc quits with ``Redeclaration of precedence of ASGNOP, line 75''
		# so switch to bison, sigh...
		YACC='bison -y'
		;;
	IRIX64)
		CC=c89
		CFLAGS='-O2'
		;;
	Linux)
		CC=gcc
		CFLAGS='-O3'	
		;;
	Mach)
		CC=gcc
		CFLAGS='-O3 -m68030'
		;;
	OSF1)
		CC=c89
		CFLAGS=-O4
		;;
	SunOS)
		case "`uname -r`" in
			4.*)
				CC='acc'
				CFLAGS='-O2 -dalign -libmil -cg89'
				;;
			5.5)
				CC="gcc -ansi"
				CC=c89
				CFLAGS='-xO5 -dalign -xlibmil -fsimple=2 -fns -xsafe=mem -xtarget=ultra1/2200'
				;;
			5.*)
				CC="gcc -ansi"
				CC=c89
				CFLAGS='-xO5 -dalign -xlibmil -fsimple=2 -fns -xsafe=mem -xtarget=ultra2/2300'
				;;
			*)
				echo "Unrecognized SunOS version...proceeding with defaults and fingers crossed :^)"
				CC=c89
				CFLAGS='-O'
				;;
		esac
		;;
	*)
		echo "Unrecognized operating system...proceeding with defaults and fingers crossed :^)"
		CFLAGS='-O'
		;;
esac

if test -f Makefile 
then
	make distclean
else
	rm -f *.o config.cache config.log config.status awklex maketab \
		proctab.c ytab.c ytab.h
fi

echo 'CC             =' $CC
echo 'CFLAGS         =' $CFLAGS
echo 'YACC           =' $YACC
echo 'YFLAGS         =' $YFLAGS

env CC="${CC}" ./configure && make CFLAGS="$CFLAGS" YACC="${YACC}" YFLAGS="${YFLAGS}" all check
