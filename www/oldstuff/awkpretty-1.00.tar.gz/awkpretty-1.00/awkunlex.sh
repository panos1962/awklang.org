#! /bin/sh
### ====================================================================
###  @UNIX-shell-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.00",
###     date            = "30 March 1999",
###     time            = "16:47:55 MST",
###     filename        = "awkunlex.sin",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "45585 105 355 3179",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "awk, lexer, lexical analyzer, unlexer",
###     supported       = "yes",
###     docstring       = "This Bourne-shell-compatible script directs
###                        the recombining of a lexical token stream
###                        from awklex back into a prettyprinted awk
###                        program.
###
###                        Usage:
###                            awkunlex -f token-stream-file >awk-file
###                            awkunlex token-stream-file(s) >awk-file
###                            awkunlex < token-stream-file >awk-file
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

### This value is set at configure time in the output awkunlex.sh file:
AWK=/usr/local/bin/gawk

# Special check for developer: use files in local directory
if test -f ./awkunlex.awk -a -x ./awklex
then
	LIBDIR=.
else
	LIBDIR=/usr/local/share/awkunlex/awkunlex-@VERSION@
fi

usage()
{
	echo "Usage:"
	echo "    awkunlex [-?] [-f file] [-h] [file(s)]"
	echo ""
	echo "or"
	echo ""
	echo "    awkunlex [--?] [--file file] [--help] [file(s)]"
}


files=
while test $# -gt 0
do
	case $1 in
	-f|--file|--fil|--fi|--f)
		files="$files $2"
		shift
		;;
	-h|-[?]|--[?]|--help|--hel|--he|--h)
		usage
		exit 0
		;;
	-v|--version|--versio|--versi|--vers|--ver|--ve|--v)
		echo "$0 Version @VERSION@ @DATE@"
		exit 0
		;;
	-*)
		for f in 1
		do
			echo "Unrecognized option $1"
			usage
		done 1>&2
		exit 1
		;;
	*)
		files="$files $1"
		;;
	esac
	shift
done

### If there are no command-line files, set files to the magic hyphen.

if test -z "$files"
then
	files=-
fi

$AWK -f $LIBDIR/awkunlex.awk $files
