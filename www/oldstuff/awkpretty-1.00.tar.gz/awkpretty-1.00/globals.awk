### ====================================================================
###  @Awk-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.00",
###     date            = "29 March 1999",
###     time            = "07:42:48 MST",
###     filename        = "globals.awk",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "52789 68 277 2334",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "",
###     supported       = "yes",
###     docstring       = "This is an awk program to list on stderr the
###                        global variables identified in its input
###                        token stream from awklex.  The input stream
###                        is echoed to stdout, so this program can be
###                        used in a pipeline.
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

BEGIN	{
	    FS = "\t"
	    fcn = "-OUTER-"
	}

($2 == "FUNC"),($3 == ")") \
	{
	    print
	    if ($2 == "CALL")
		fcn = $3
	    next
	}

$2 == "VAR" \
	{
	    print
	    GlobalVars[fcn,$3]++
	    next
	}

	{ print }

END	{
	    for (fv in GlobalVars)
	    {
		split(fv,vars,SUBSEP)
		## gawk and mawk accept this, but awk and nawk do not:
		## printf("%-31s\t%s\n", vars[1], vars[2]) | "sort"  > "/dev/stderr"
		printf("%-31s\t%s\n", vars[1], vars[2]) | "sort 1>&2"
	    }
	}
