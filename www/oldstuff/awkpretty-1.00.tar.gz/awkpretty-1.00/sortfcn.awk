### ====================================================================
###  @Awk-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.00",
###     date            = "03 April 1999",
###     time            = "16:18:39 MST",
###     filename        = "sortfcn.awk",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "33371 120 635 4813",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "awk, function sorting, prettyprinter",
###     supported       = "yes",
###     docstring       = "This is an awk program to filter output of
###                        awklex, sorting functions into alphabetical
###                        order, ignoring lettercase.
###
###                        It inserts suitable SORTKEY strings based on
###                        the function names, and replaces newlines by
###                        Ctl-B, except immediately before the SORTKEY
###                        strings, and at end of file, where there are
###                        newlines.
###
###                        That output is then sent through a pipeline
###                        with an initial sort stage to sort the main
###                        body of code into the first record, with each
###                        function following in the desired order.
###
###                        A tr stage then converts Ctl-B back to
###                        newline, and a final egrep stage removes the
###                        SORTKEY lines and the empty lines which were
###                        introduced by the process of creating sort
###                        records.
###
###                        A Ctl-B is a safe record separator, since
###                        awklex converts any such characters inside
###                        strings to escape sequences.  Since Ctl-B is
###                        not printable, it is very unlikely to occur
###                        in other text in the input awk token stream.
###
###                        However, to be completely safe, we convert
###                        any pre-existing Ctl-B characters to a unique
###                        pattern formed using a large pseudo-random
###                        number, and then include a post-sort pipeline
###                        stage to replace that pattern by Ctl-B.
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

BEGIN \
    {
	Sortkey = "SORTKEY-"
	srand()	# seed with time-of-day, so each run gets a new pattern
	randint = int(2147483647 * rand())
	Ctl_B = "<Ctl-B-" randint ">"

	# On most systems, no sort flags that specify memory
	# requirements are needed.  However, on IBM RS/6000 AIX 4.2
	# systems, failure to specify an adequate maximum line length
	# results in silent destruction of data, sigh... Adding -z
	# 4194304 allows records up to 4MB in size, which should be more
	# than sufficient. Unfortunately, some systems (Sun SunOS 4.1.x,
	# DEC Alpha OSF/1 3.x, NeXT Mach 3.3, ...) do not support the -z
	# flag, so we need an if test in the pipeline, double sigh...
	sortpipe = "if sort -f -z 4194304 </dev/null >/dev/null 2>/dev/null ; " \
		" then sort -f -z 4194304 ; else sort -f ; fi" \
		" | tr '\002' '\n'" \
		" | sed -e 's/" Ctl_B "//g'" \
		" | egrep -v '^" Sortkey "|^$'"

	ORS = "\002"
	print Sortkey "\001" | sortpipe
	save = ""
    }

($1 == 0) \
    {
	# ensure that special EOF token sorts at end of token stream
	print "\n" Sortkey "\377" $0 "\n" | sortpipe
	next
    }

($2 == "FUNC"),($2 == "CALL") \
    {
	gsub("",Ctl_B)
	save = save ORS $0
	if ($2 == "CALL")
	{
	    printf("\n") | sortpipe
	    print Sortkey $3 | sortpipe
	    print save | sortpipe
	    save = ""
	}
	next
    }

    {
	gsub("",Ctl_B)
	print | sortpipe
    }

END {
	ORS = "\n"
	print ""  | sortpipe
    }
