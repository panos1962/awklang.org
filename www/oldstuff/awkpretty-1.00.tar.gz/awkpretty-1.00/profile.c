/* /u/sy/beebe/bwkawk/profile.c, Tue Nov 12 13:23:40 1996 */
/* Edit by Nelson H. F. Beebe <beebe@plot79.math.utah.edu> */

/***********************************************************************
This file provides relatively generic profiling support for other
programs.

On systems for which CPU_clock() can provide a cheap and accurate cycle
count, the profiling can be both low-overhead, and accurate.  This is
currently implemented only for the DEC Alpha, although it should be
possible on the IBM PowerPC too. Sadly, although the Sun UltraSPARC chip
has the necessary timer hardware, the Sun Solaris operating system
refuses to make it available, even to the root user.

On most systems, however, timing via the clock() or times() functions is
expensive, since it involves a kernel call, with its concomitant context
switches.

Although clock() is defined in ANSI/ISO Standard C, older K&R-style C
implementations may provide times() instead.  This difference is
concealed from the caller, who need only invoke the two public functions
CPU_clock() and CPU_CLOCKS_PER_SEC():

	#include "cpuclock.h"
	...
	CPU_clock_t t_in, t_out;
	...
	t_in = CPU_clock();
	... do some work ...
	t_out = CPU_clock();
	...
	printf("cycles: %10ld\n",(long)(t_out - t_in));
	printf("time:   %10.6f sec\n",
		(double)(t_out - t_in)/CPU_CLOCKS_PER_SEC());

Thus, CPU_clock() and CPU_CLOCKS_PER_SEC() are direct analogues of
clock() and CLOCKS_PER_SEC.

The one difference is that CPU_CLOCKS_PER_SEC() is a function.  On its
first call, it requires about two seconds to compute and save its return
value; on subsequent calls, it quickly returns the previously saved
value.  CLOCKS_PER_SEC is usually a constant, though on some systems, it
might be a function call, perhaps to sysconf().

***********************************************************************/

#if defined(PROFILE)			/* nothing gets compiled unless this symbol */
					/* is defined */
#include "config.h"

#include <stdio.h>
#include <string.h>

#if defined(HAVE_STDLIB_H)
#include <stdlib.h>
#endif

#if defined(HAVE_UNISTD_H)
#include <unistd.h>
#endif

#include "cpuclock.h"
#include "profile.h"

#if !defined(MAXPROFILE)		/* supply default if not set at compile time  */
#define MAXPROFILE	16383		/* big enough for almost any program, and */
					/* small enough to use on Intel x86 64KB segment */
#endif /* !define(MAXPROFILE) */

static int profile_on = 0;		/* non-zero value turns on profiling */

static CPU_clock_t	ClockTicks[MAXPROFILE];
static CPU_clock_t	ClockTicks_End;
static CPU_clock_t	ClockTicks_LineStart;
static CPU_clock_t	ClockTicks_Start;
static long		LineTicks[MAXPROFILE];
static double		total_ClockTicks; /* type double to avoid premature overflow on 32-bit systems */

static int		profile_argc;
static char		**profile_argv;

FILE			*stdprofile;

static int		cmp_ClockTicks ARGS((const void *p, const void *q));
static double		ClockTicks_per_LineTick ARGS((clock_t the_ClockTicks,
						      long the_LineTicks));
static int		cmp_ClockTicks_per_LineTick ARGS((const void *p, const void *q));
static int		cmp_LineNumbers ARGS((const void *p, const void *q));
static int		cmp_LineTicks ARGS((const void *p, const void *q));
static double		percent_ClockTicks ARGS((clock_t the_ClockTicks));
static void		profile_separator ARGS((void));
static void		profile_table ARGS((const char *order, int line[],
					    lineno_t max_lineno));




/************************** Private functions *************************/

static int
#if STDC
cmp_ClockTicks(const void *p, const void *q)
#else
cmp_ClockTicks(p,q)
const void *p;
const void *q;
#endif
{
	lineno_t p_lineno, q_lineno;

	p_lineno = *((const lineno_t*)p);
	q_lineno = *((const lineno_t*)q);

	if (ClockTicks[p_lineno] < ClockTicks[q_lineno])
		return (1);		/* descending order */
	else if (ClockTicks[p_lineno] > ClockTicks[q_lineno])
		return (-1);
	else if (p_lineno < q_lineno)	/* times are equal: order by ascending line numbers */
		return (-1);
	else if (p_lineno > q_lineno)
		return (1);
	else
		return (0);
}

static double
#if STDC
ClockTicks_per_LineTick(clock_t the_ClockTicks, long the_LineTicks)
#else
ClockTicks_per_LineTick(the_ClockTicks, the_LineTicks)
clock_t the_ClockTicks;
long the_LineTicks;
#endif
{
	return (double)the_ClockTicks/(double)((the_LineTicks > 0) ? the_LineTicks : 1);
}

static int
#if STDC
cmp_ClockTicks_per_LineTick(const void *p, const void *q)
#else
cmp_ClockTicks_per_LineTick(p,q)
const void *p;
const void *q;
#endif
{
	lineno_t p_lineno, q_lineno;
	double cplpp, cplqq;

	p_lineno = *((const lineno_t*)p);
	q_lineno = *((const lineno_t*)q);

	cplpp = ClockTicks_per_LineTick(ClockTicks[p_lineno],LineTicks[p_lineno]);
	cplqq = ClockTicks_per_LineTick(ClockTicks[q_lineno],LineTicks[q_lineno]);

	if (cplpp < cplqq)
		return (1);		/* descending order */
	else if (cplpp > cplqq)
		return (-1);
	else if (p_lineno < q_lineno)	/* times are equal: order by ascending line numbers */
		return (-1);
	else if (p_lineno > q_lineno)
		return (1);
	else
		return (0);
}

static int
#if STDC
cmp_LineNumbers(const void *p, const void *q)
#else
cmp_LineNumbers(p,q)
const void *p;
const void *q;
#endif
{
	lineno_t p_lineno, q_lineno;

	p_lineno = *((const lineno_t*)p);
	q_lineno = *((const lineno_t*)q);

	if (p_lineno < q_lineno)
		return (-1);		/* ascending order */
	else if (p_lineno > q_lineno)
		return (1);
	else
		return (0);
}

static int
#if STDC
cmp_LineTicks(const void *p, const void *q)
#else
cmp_LineTicks(p,q)
const void *p;
const void *q;
#endif
{
	lineno_t p_lineno, q_lineno;

	p_lineno = *((const lineno_t*)p);
	q_lineno = *((const lineno_t*)q);

	if (LineTicks[p_lineno] < LineTicks[q_lineno])
		return (1);		/* descending order */
	else if (LineTicks[p_lineno] > LineTicks[q_lineno])
		return (-1);
	else if (p_lineno < q_lineno)	/* LineTicks are equal: order by ascending line numbers */
		return (-1);
	else if (p_lineno > q_lineno)
		return (1);
	else
		return (0);
}

static double
#if STDC
percent_ClockTicks(clock_t the_ClockTicks)
#else
percent_ClockTicks(the_ClockTicks)
clock_t the_ClockTicks;
#endif
{
	return (100.0 * (double)the_ClockTicks / total_ClockTicks);
}

static void
profile_separator(VOID_ARG)
{
	fprintf(stdprofile,
		"================================================================\n");
}

static void
#if STDC
profile_table(const char *order, int line[], lineno_t max_lineno)
#else
profile_table(order,line,max_lineno)
const char *order;
int line[];
lineno_t max_lineno;
#endif
{
	int k;
	lineno_t this_lineno;

	fprintf(stdprofile,"\f\n");	/* start new page for this table */
	profile_separator();
	fprintf(stdprofile,
		"Execution profile in %s order\n\n",
		order);

	fprintf(stdprofile,"Command: ");
	for (k = 0; k < profile_argc; ++k)
	{
		const char *quote;

		/* We need to quote the argument if it contains shell metachars */
		quote = (strpbrk(profile_argv[k]," ;&()|*?[]{}()~<>!^\"'\\$@")
			== (char*)NULL) ? "" : "'";
		fprintf(stdprofile,
			"%s%s%s%s",
			quote, profile_argv[k], quote,
			((k == (profile_argc-1)) ? "\n\n" :
			 ((profile_argv[k][0] == '-') ? " " : " \\\n\t\t")));
	}

	fprintf(stdprofile,
		"Clock resolution: %10ld ticks/second\n\n",
		(long)CPU_CLOCKS_PER_SEC());

	fprintf(stdprofile,
		"Total ClockTicks: %.0f (== %.3f sec)\n\n",
		(double)total_ClockTicks,
		(double)total_ClockTicks/(double)CPU_CLOCKS_PER_SEC());

	fprintf(stdprofile,
		"Delta ClockTicks: %10ld (== %.3f sec)\n\n",
		(long)(ClockTicks_End - ClockTicks_Start),
		(double)(ClockTicks_End - ClockTicks_Start)/(double)CPU_CLOCKS_PER_SEC());

	fprintf(stdprofile,
		"Line:   LineTicks  ClockTicks  ClockTicks/LineTick   %%ClockTicks\n");
	if (LineTicks[0] > 0)	/* warn user if our profile tables were too small */
	{
		fprintf(stdprofile,
			"WARNING: more than %ld program lines.\n",
			(long)MAXPROFILE);
		fprintf(stdprofile,"Results for higher line numbers are totalled at line 0.\n");
	}
	profile_separator();

	for (this_lineno = 0; this_lineno <= max_lineno; ++this_lineno)

	{
		if (LineTicks[line[this_lineno]] > 0L) /* print only non-zero results */
			fprintf(stdprofile,
				"%5ld:%11ld %11ld %18.4f %13.3f\n", /* NB: matches header format above */
				(long)line[this_lineno],
				(long)LineTicks[line[this_lineno]],
				(long)ClockTicks[line[this_lineno]],
				ClockTicks_per_LineTick(ClockTicks[line[this_lineno]],
							LineTicks[line[this_lineno]]),
				percent_ClockTicks(ClockTicks[line[this_lineno]]));
	}
	profile_separator();
}

/************************** Public functions **************************/

void
profile(VOID_ARG)
{
	if (profile_on)
	{
		lineno_t max_lineno;
		lineno_t this_lineno;
		int line[MAXPROFILE];

		ClockTicks_End = CPU_clock();

		/* To speed the sorts, find out how many lines of data we actually
		   have, and also compute the total ClockTicks accumulated, which
		   is needed for the profile tables. */
		max_lineno = 0;
		total_ClockTicks = (double)0.0;
		for (this_lineno = 0; this_lineno < MAXPROFILE; ++this_lineno)
		{
		    line[this_lineno] = this_lineno;
		    if (LineTicks[this_lineno] > 0)
			max_lineno = this_lineno;
		    total_ClockTicks += (double)ClockTicks[this_lineno];
		}

		/* Print the four profile tables in order of decreasing
		   importance for program tuning. */

		qsort(line, max_lineno, sizeof(line[0]), cmp_ClockTicks);
		profile_table("descending ClockTicks",line,max_lineno);

		qsort(line, max_lineno, sizeof(line[0]), cmp_LineTicks);
		profile_table("descending LineTicks",line,max_lineno);

		qsort(line, max_lineno, sizeof(line[0]), cmp_ClockTicks_per_LineTick);
		profile_table("descending ClockTicks/LineTick",line,max_lineno);

		qsort(line, max_lineno, sizeof(line[0]), cmp_LineNumbers);
		profile_table("ascending LineNumber",line,max_lineno);

		/* Clear counters after each profile. */
		(void)memset(ClockTicks, 0, sizeof(ClockTicks));
		(void)memset(LineTicks, 0, sizeof(LineTicks));
	}
}

void
#if STDC
profile_begin_line(lineno_t lineno)
#else
profile_begin_line(lineno)
lineno_t lineno;
#endif
{
	if (profile_on)
	{
		lineno_t this_lineno;

		/* When MAXPROFILE is too small, we accumulate results for line 0 */
		this_lineno = (lineno <= MAXPROFILE) ? lineno : 0;
		LineTicks[this_lineno]++;
		ClockTicks_LineStart = CPU_clock();
	}
}


void
#if STDC
profile_end_line(lineno_t lineno)
#else
profile_end_line(lineno)
lineno_t lineno;
#endif
{
	if (profile_on)
	{
		lineno_t this_lineno;

		/* When MAXPROFILE is too small, we accumulate results for line 0 */
		this_lineno = (lineno <= MAXPROFILE) ? lineno : 0;
		ClockTicks[this_lineno] +=  CPU_clock() - ClockTicks_LineStart;
	}
}

void
#if STDC
profile_init(int argc, char **argv)
#else
profile_init(argc,argv)
int argc;
char **argv;
#endif
{
	char *p;

	profile_argc = argc;		/* remember command-line arguments in */
	profile_argv = argv;		/* private global variables */

	/* The environment variable PROFILE can be set to select
	   profiling. Its value is 1 for profiling on stdout, 2 for
	   profiling on stderr, and otherwise, is a file name for the
	   profiling results.  An open failure on that file name results
	   in silent reversion to stderr. */

	p = getenv("PROFILE");
	profile_on = (p != (char*)NULL);
	if (profile_on)
	{
		switch (atoi(p))
		{
		case 1:
			stdprofile = stdout;
			break;
		case 2:
			stdprofile = stderr;
			break;
		default:
			stdprofile = fopen(p,"w");
			if (stdprofile == (FILE*)NULL)
				stdprofile = stderr;
		}
		ClockTicks_Start = CPU_clock();
	}
}

void
profile_term(VOID_ARG)
{
	if (profile_on && (stdprofile != stdout) && (stdprofile != stderr))
		(void)fclose(stdprofile);
	stdprofile = stderr;		/* restore default */
	profile_on = 0;
}
#endif /* defined(PROFILE) */
