#! /bin/sh
#=======================================================================
# Run a regression test on awklex, awkpretty, and awkunlex: the filter
# chains
#
#	awklex file(s)
#	awklex file(s) | awkunlex | awklex
#
# and
#
#	awklex file(s)
#	awklex file(s) | awkpretty | awklex
#
# should produce the same lexical token streams, except for line
# numbers, whitespace, tabs in comments, and possibly, newlines.
#
# Usage:
#	./regress.sh awk-file(s)
#
# [04-Apr-1999]
#=======================================================================

TMPFILE=/tmp/regress.$$
trap '/bin/rm -f ${TMPFILE}.?' 0 1 2 3 15
IGNOREFILTER="egrep -v '337	WHITESPACE|^#|263	NL'"

for f in "$@"
do
	if test -f $f -a -r $f
	then
		echo "============ awkunlex: " $f
		./awklex -f $f >$TMPFILE.2
		eval "$IGNOREFILTER $TMPFILE.2" >$TMPFILE.1
		eval "./awkunlex.sh  -f $TMPFILE.2 | ./awklex -f - | $IGNOREFILTER | diff $TMPFILE.1 -"
		echo "============ awkpretty:" $f
		eval "./awkpretty.sh -f $TMPFILE.2 --awklex-input | ./awklex -f - | $IGNOREFILTER | diff $TMPFILE.1 -"
	fi
done
