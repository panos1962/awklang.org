### ====================================================================
###  @Awk-file{
###     author          = "Nelson H. F. Beebe",
###     version         = "1.00",
###     date            = "29 March 1999",
###     time            = "09:04:18 MST",
###     filename        = "awkunlex.awk",
###     address         = "Center for Scientific Computing
###                        University of Utah
###                        Department of Mathematics, 322 INSCC
###                        155 S 1400 E RM 233
###                        Salt Lake City, UT 84112-0090
###                        USA",
###     telephone       = "+1 801 581 5254",
###     FAX             = "+1 801 585 1640, +1 801 581 4148",
###     URL             = "http://www.math.utah.edu/~beebe",
###     checksum        = "25558 113 530 4151",
###     email           = "beebe@math.utah.edu, beebe@acm.org,
###                        beebe@ieee.org (Internet)",
###     codetable       = "ISO/ASCII",
###     keywords        = "awk, lexer, lexical analyzer, unlexer",
###     supported       = "yes",
###     docstring       = "This program reconstructs a lexical token
###                        stream from awklex back into an awk
###                        program.
###
###                        Unlike awkpretty, it does not format the
###                        text in any way, so that the output should
###                        match the original input to awklex exactly,
###                        except possibly for the representation of
###                        non-printable characters inside strings,
###                        which awklex transforms to character and
###                        octal escape sequences.
###
###                        Usage:
###                            awkunlex -f file >new-awk-file
###                            awkunlex [file(s)] >new-awk-file
###
###                        The accompanying manual pages document this
###                        program in detail.
###
###                        The checksum field above contains a CRC-16
###                        checksum as the first value, followed by the
###                        equivalent of the standard UNIX wc (word
###                        count) utility output of lines, words, and
###                        characters.  This is produced by Robert
###                        Solovay's checksum utility.",
###  }
### ====================================================================

BEGIN					{ initialize() }

### Ignore all lexical analyzer directives and comments
/^ *#/					{ next }

### Ignore empty lines; although awklex does not produce any, other
### filters might.
/^[ \t]*$/				{ next }

### Skip token from apparent bug in lexical analyzer output
($3 == "}") && ($2 == "token 59")	{ next }

### Strictly, we should pass value() to process() as a second argument,
### but about half the time (e.g., whitespace and newlines), we don't
### need the value, so we optimize by delaying the call to value() until
### we really need it.
					{ process($2) }

END					{ terminate() }

# ========================================================================

function initialize()
{
    FS = "\t"		# tabs separate input: NUMBER<TAB>TYPE<TAB>VALUE
			# but VALUE itself may contain further tabs, so
			# function value() handles that detail when necessary
}


function process(type)
{
    ## This is a simple version of process(), used for testing the basic
    ## handling of the input token stream.  The output should be
    ## identical to the input to awklex, except for backslash-newline
    ## collapses, and possible changes in representation of non-printable
    ## ASCII characters in 0..31.
    if (type == "NL") # special case: newline token is empty in input stream
	print ""
    else if (type == "STRING")
	printf("%s", value())
    else
	printf("%s", value())
}


function terminate()
{
}


function value( k,v)
{
    if (NF == 3 )		# simple case: no tabs in token
	v = $3
    else			# complex case: reconstruct token from $3 TAB $4 TAB ... $NF
    {
	v = $3
	for (k = 4; k <= NF; ++k)
	    v = v "\t" $k
    }
    return (v)
}
