#ifndef CPU_CLOCK_H__

#define CPU_CLOCK_H__ 1


/* This file provides public declarations of the CPU_clock_t type and
   the CPU_clock() function.

   On machines where a high-accuracy cycle counter is not available,
   it transparently uses the ANSI/ISO Standard C clock_t and clock()
   function.

   The DEC Alpha has a user-accessible cycle counter, allowing precise
   timing without the overhead of a system call and its concomitant
   context switches.  */

#include "args.h"

#if defined(__alpha__)
/* On the DEC Alpha, clock_t is a 32-bit signed int, but we want a
64-bit signed counter, CPU_clock_t */
typedef long CPU_clock_t;		/* this is a 64-bit value on the DEC Alpha */
#else
#if defined(_IBMR2) && defined(HAVE_READ_REAL_TIME)
typedef long long CPU_clock_t;		/* this is a 64-bit value on the IBM RS/6000 AIX 4.x */
#else
typedef clock_t CPU_clock_t;		/* use ANSI/ISO Standard C clock_t instead */
#endif
#endif

CPU_clock_t	CPU_clock(VOID_ARG);
long		CPU_CLOCKS_PER_SEC(VOID_ARG);

#endif /* CPU_CLOCK_H__ */
