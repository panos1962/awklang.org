# StepMode.awk - primitive single-step mode function for `gawk'
# Arthur Pool .. pool@commerce.uq.edu.au
# $Id: StepMode.awk,v 1.6 1998-03-18 12:12:10+10 pool Exp pool $

# Syntax: gawk -f StepMode.awk -f Normal_program.awk < input stream

# When used as shown, `StepMode' will pause after each record is read from
# `stdin' and prompt the user for a response.
# The user can then either:
#  - press `enter' to step to the next record;
#  - enter `skip nn' to process the next `nn' records without interaction;
#  - enter `skip' to process the remainder of the input stream without
#    interaction.
#  - enter `exit [rc]' to exit gawk with (optional) return code `rc'.

# Notes: 
# 1) Uses variable `Interactive_StepMode_Var' for global data!
# 2) Uses filename "CON" to communicate directly with the terminal,
#    bypassing any other piped input - that is, without interfering with
#    (or being interfered with by) either `stdin' or `stdout'. 
#    This works under OS/2 - I don't know about other environments. 

# Global Variable `Interactive_StepMode_Var':
#       ==0     => first entry - initialisation + single step mode
#        <0     => no more tracing
#       ==1     => single step mode
#        >1     => skipping to target record `nn'

# Tue Mar 24 10:55:36 IDT 1998:
# reformatted, but otherwise unchanged
# Arnold Robbins, arnold@gnu.org

{
	Interactive_StepMode()
}

function Interactive_StepMode(ignore,  parts, n, i)
{
	if (Interactive_StepMode_Var < 0)
		return
	if (Interactive_StepMode_Var > 1) {
		if (NR > Interactive_StepMode_Var)
			Interactive_StepMode_Var = 1
	}
	if (Interactive_StepMode_Var == 0) {
		if (Interactive_StepMode_Var == 0) {
			print "Interactive STEP mode...  `?' for help" > "CON"
		}
		Interactive_StepMode_Var = 1
	}
	if (Interactive_StepMode_Var == 1) {
		print "  >>> ["NR"]" > "CON"
		for (i = 1; ; i++) {
			getline stuff < "CON"
			n = split(toupper(stuff), parts)
			if (n == 0)
				return
			else if (substr("SKIP", 1, length(parts[1])) == parts[1]) {
				if (n == 1)
					Interactive_StepMode_Var = -1
				else
					Interactive_StepMode_Var = NR + parts[2]
				return
			} else if (substr("EXIT", 1, length(parts[1])) == parts[1]) {
				if (n > 1)
					exit parts[2]
				else
					exit 0
			} else {
				print \
	"? ENTER to continue to the next record,\n" \
	"`Skip' to continue without any further interaction,\n" \
	"`Skip nn' to process the next `nn' records without interaction,\n" \
	"`Exit [rc]' to exit `gawk' with (optional) return code `rc'." > "CON"
			}
		}
	}
}
